BIODIVERSITY DATA RESCUE PACKAGE

original/: exact imported bytes. Do not edit this source.
cleaned.csv: UTF-8 comma-delimited working table; all values are strings.
metadata.json: dataset context, column definitions, parsing choices and source hash.
datapackage.json: tabular data package descriptor, with biodiversity extensions.
audit.json: ordered timestamped actions with before/after snapshots and reasons.
quality-report.json: unresolved rule-based flags and column profiles at export.
project.biorescue.json: portable project, reopen in the Workbench.
checksums.sha256: SHA-256 of each other file in this package.

REVIEW BEFORE SHARING: exact coordinates and original workbook content can be sensitive.
Metadata and term mappings are user assertions, not validated scientific claims.
Blank values remain blank; zero remains zero. No absence or effort was inferred.

SPREADSHEET SAFETY: CSV cells beginning with =, +, -, or @ can be interpreted as
formulas by spreadsheet software. Import all columns explicitly as TEXT; avoid
double-clicking the CSV. Literal values are preserved for reproducibility.
Excel formula caches and date serials require manual review.
