PUBLIC COORDINATE EXPORT
Originals, project backups, evidence, audit snapshots, raw metadata and private reports deliberately excluded. Review remaining free-text fields for sensitive information. Import CSV columns as text to preserve identifiers and avoid formula execution.
