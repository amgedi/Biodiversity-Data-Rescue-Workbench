# Biodiversity Rescue Report

Project: Woodland 2008 · guided fictional rescue

Application: 0.2.0
Project created: 2026-09-30T19:20:20.890Z

Technical validity is not scientific correctness.

## Original files

- events_2008.csv · 112 bytes · imported 2026-09-30T19:20:20.844198+00:00
  SHA-256: `30e5cf99bb17e2317716120a9ff42e42d3c4d6927ecd6bbaf050db7b85cbc525`
  Format: csv; conversion: see structure observations
- taxa_2008.csv · 160 bytes · imported 2026-09-30T19:20:20.845251+00:00
  SHA-256: `4328ac702327a65f248d413cd5cb98dbc2144ba7c2ff8cfdca5f69e52b5b2a86`
  Format: csv; conversion: see structure observations
- obs_2008.csv · 267 bytes · imported 2026-09-30T19:20:20.846263+00:00
  SHA-256: `1f8f52f32ed35a9651ec89cf981155236f57d0438b735d6f33741960042334a4`
  Format: csv; conversion: see structure observations
- protocol_2008.txt · 1264 bytes · imported 2026-09-30T19:20:20.846828+00:00
  SHA-256: `dbba42a07bdf56362f1fe84ff5f88472cd9aac85b872c58a9940c95cf0f0d9e7`
  Format: txt; conversion: Intentionally preserved as supporting evidence without tabular conversion.

## Tables

- events_2008: 3 rows, 4 columns; primary key: not confirmed
  - event_id: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 
  - site: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 
  - effort_min: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 
  - dt: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 
- taxa_2008: 3 rows, 3 columns; primary key: not confirmed
  - taxon_code: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 
  - scientific_name: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 
  - common_name: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 
- obs_2008: 6 rows, 8 columns; primary key: not confirmed
  - record_id: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 
  - event_id: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 
  - taxon_code: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 
  - n: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 
  - lat: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 
  - lon: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 
  - dt: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 
  - code: meaning unknown [Unknown]; term unmapped; evidence none recorded; rationale 

## Confirmed metadata

- title: Woodland 2008 · guided fictional rescue; evidence: none recorded; rationale: 
- description: Deliberately messy fictional biodiversity records. Not real field observations. Training data includes unknown dates, undocumented codes and questionable coordinates.; evidence: none recorded; rationale: The example was authored explicitly for this tutorial.
- license: CC0-1.0 (fictional tutorial files only); evidence: protocol_2008.txt; rationale: Explicit license statement in the fictional training protocol.

## Inferred metadata


## Unknown metadata

- purpose: unknown; evidence: none recorded; rationale: 
- creator: unknown; evidence: none recorded; rationale: 
- contributors: unknown; evidence: none recorded; rationale: 
- contact: unknown; evidence: none recorded; rationale: 
- organizations: unknown; evidence: none recorded; rationale: 
- citation: unknown; evidence: none recorded; rationale: 
- publicationDate: unknown; evidence: none recorded; rationale: 
- funding: unknown; evidence: none recorded; rationale: 
- methods: unknown; evidence: none recorded; rationale: 
- samplingProtocol: unknown; evidence: none recorded; rationale: 
- studyDesign: unknown; evidence: none recorded; rationale: 
- temporalCoverage: unknown; evidence: none recorded; rationale: 
- spatialCoverage: unknown; evidence: none recorded; rationale: 
- taxonomicCoverage: unknown; evidence: none recorded; rationale: 
- keywords: unknown; evidence: none recorded; rationale: 
- originalSoftware: unknown; evidence: none recorded; rationale: 
- publications: unknown; evidence: none recorded; rationale: 
- limitations: unknown; evidence: none recorded; rationale: 
- provenance: unknown; evidence: none recorded; rationale: 
- sensitivity: unknown; evidence: none recorded; rationale: 
- datum: unknown; evidence: none recorded; rationale: 
- coordinateUncertainty: unknown; evidence: none recorded; rationale: 

## Conflicting metadata


## Not Applicable metadata


## Relationships


## Repairs and provenance

- 2026-09-30T19:20:20.894Z · preserve source: Original bytes archived; tables are independent working copies. Import structure and unsupported features remain recorded.
- 2026-09-30T19:20:20.894Z · preserve source: Original bytes archived; tables are independent working copies. Import structure and unsupported features remain recorded.
- 2026-09-30T19:20:20.894Z · preserve source: Original bytes archived; tables are independent working copies. Import structure and unsupported features remain recorded.
- 2026-09-30T19:20:20.895Z · preserve source: Original bytes archived; tables are independent working copies. Import structure and unsupported features remain recorded.

## Validation

- Information / metadata: Define “event_id” — Record what this field means, including collection conventions.
- Information / metadata: Define “site” — Record what this field means, including collection conventions.
- Warning / scientific: Whitespace in site — 1 values have leading or trailing whitespace.
- Information / metadata: Define “effort_min” — Record what this field means, including collection conventions.
- Information / scientific: Blank values in effort_min — 1 of 3 values are blank or whitespace. Blank does not mean zero or absence.
- Information / metadata: Define “dt” — Record what this field means, including collection conventions.
- Warning / scientific: Mixed types in dt — Observed types: text (1), date-like (1), integer (1). Values are preserved as strings.
- Warning / scientific: Ambiguous dates in dt — 1 dates need a documented day/month convention. No dates have been converted.
- Information / scientific: Partial dates in dt — Year or month precision is preserved. Do not invent a day.
- Information / metadata: Define “taxon_code” — Record what this field means, including collection conventions.
- Information / metadata: Define “scientific_name” — Record what this field means, including collection conventions.
- Information / metadata: Define “common_name” — Record what this field means, including collection conventions.
- Warning / scientific: Exact duplicate rows — 1 repeated rows. Repeated observations can be valid; confirm before removing.
- Information / metadata: Define “record_id” — Record what this field means, including collection conventions.
- Information / scientific: Leading zeros in record_id — Keep these values as text when opening exports to preserve identifiers.
- Information / metadata: Define “event_id” — Record what this field means, including collection conventions.
- Information / metadata: Define “taxon_code” — Record what this field means, including collection conventions.
- Information / scientific: Blank values in taxon_code — 1 of 6 values are blank or whitespace. Blank does not mean zero or absence.
- Information / metadata: Define “n” — Record what this field means, including collection conventions.
- Warning / scientific: Whitespace in n — 1 values have leading or trailing whitespace.
- Warning / scientific: Mixed types in n — Observed types: integer (4), text (2). Values are preserved as strings.
- Warning / scientific: Possible missing tokens in n — 1 values use a common missing-value marker. Confirm the convention before normalizing.
- Information / metadata: Define “lat” — Record what this field means, including collection conventions.
- Warning / scientific: Possible missing tokens in lat — 1 values use a common missing-value marker. Confirm the convention before normalizing.
- Warning / scientific: Invalid latitude range — 2 values fall outside ±90 or are not numeric. Confirm units and coordinate reference system.
- Information / metadata: Define “lon” — Record what this field means, including collection conventions.
- Warning / scientific: Invalid longitude range — 1 values fall outside ±180 or are not numeric. Confirm units and coordinate reference system.
- Information / metadata: Define “dt” — Record what this field means, including collection conventions.
- Warning / scientific: Mixed types in dt — Observed types: text (4), date-like (2). Values are preserved as strings.
- Warning / scientific: Ambiguous dates in dt — 2 dates need a documented day/month convention. No dates have been converted.
- Information / metadata: Define “code” — Record what this field means, including collection conventions.
- Warning / scientific: Possible missing tokens in code — 1 values use a common missing-value marker. Confirm the convention before normalizing.
- Warning / scientific: Spreadsheet formula-like text in code — Export preserves these values. Import the CSV as text in spreadsheet software.
- Warning / scientific: Suspicious sentinels in n — Possible missing markers; literal values remain unchanged until a documented convention is confirmed.
- Warning / scientific: Suspicious sentinels in lat — Possible missing markers; literal values remain unchanged until a documented convention is confirmed.
- Warning / scientific: Suspicious sentinels in lon — Possible missing markers; literal values remain unchanged until a documented convention is confirmed.
- Information / scientific: Partial dates in dt — Year or month precision is preserved. Do not invent a day.
- Warning / scientific: Impossible calendar dates in dt — Date-shaped text contains an invalid calendar day.
- Warning / scientific: Suspicious sentinels in code — Possible missing markers; literal values remain unchanged until a documented convention is confirmed.
- Warning / scientific: Coordinates at 0,0 — May be real or a placeholder. Review source evidence.
- Warning / scientific: Coordinates may be swapped — Latitude exceeds 90 while longitude could be a latitude. No axes were swapped.
- Warning / scientific: Coordinate datum not confirmed — Coordinate previews use reported angular values only. No datum has been assumed.
- Information / metadata: Unknown Purpose — No defensible meaning has been recovered.
- Information / metadata: Unknown Creators — No defensible meaning has been recovered.
- Information / metadata: Unknown Contributors — No defensible meaning has been recovered.
- Information / metadata: Unknown Contacts — No defensible meaning has been recovered.
- Information / metadata: Unknown Organizations — No defensible meaning has been recovered.
- Information / metadata: Unknown Citation — No defensible meaning has been recovered.
- Information / metadata: Unknown Publication / release date — No defensible meaning has been recovered.
- Information / metadata: Unknown Funding & acknowledgements — No defensible meaning has been recovered.
- Information / metadata: Unknown Methods — No defensible meaning has been recovered.
- Information / metadata: Unknown Sampling protocol — No defensible meaning has been recovered.
- Information / metadata: Unknown Study design — No defensible meaning has been recovered.
- Information / metadata: Unknown Temporal coverage — No defensible meaning has been recovered.
- Information / metadata: Unknown Geographic coverage — No defensible meaning has been recovered.
- Information / metadata: Unknown Taxonomic coverage — No defensible meaning has been recovered.
- Information / metadata: Unknown Keywords — No defensible meaning has been recovered.
- Information / metadata: Unknown Original software / system — No defensible meaning has been recovered.
- Information / metadata: Unknown Related publications / DOI / URL — No defensible meaning has been recovered.
- Information / metadata: Unknown Known limitations — No defensible meaning has been recovered.
- Information / metadata: Unknown Provenance — No defensible meaning has been recovered.
- Information / metadata: Unknown Access restrictions — No defensible meaning has been recovered.
- Information / metadata: Unknown Coordinate datum / reference system — No defensible meaning has been recovered.
- Information / metadata: Unknown Coordinate uncertainty — No defensible meaning has been recovered.

## Standard capabilities

- Frictionless Data Package / Table Schema (1): Multi-table descriptors, declared field types/constraints, primary and foreign keys; local subset validation. Full external schema validation pending.
- Darwin Core / Conceptual Model (guide 2026-05-26): Evidence-aware field mappings, explicit term IRIs, relational design. DwC-DP conformance/export pending a vendored, reviewed profile and table schemas.
- Darwin Core Archive (text guide): Pending. Do not flatten many-to-many relational data. A future conversion may select one genuine core and applicable extensions.
- Ecological Metadata Language (2.2.0): Draft XML from confirmed metadata, missing-information diagnostics. XSD validation pending; drafts are not labeled compliant EML.
- RO-Crate (1.2): Preservation metadata graph for confirmed title, description, license, publication/release date and organizational creator; local required-property checks, full profile validation pending.
- Camtrap DP (not selected): Recognizes deployments/media/observations structures; conformance validation and schema-backed export pending. No schema version assumed.

## Remaining work

Review unresolved unknowns and conflicts, validate all inferred meanings with evidence, confirm datum and date conventions, repair relationship errors, and obtain full official-schema validation before making standard-conformance claims.

## Exports

Working CSVs, schemas, datapackage.json, metadata.json, original files, structure observations, audit, recipe, source manifest, validation, this report, checksums, and a portable project. EML draft and RO-Crate metadata included only if their metadata prerequisites are met.
